#!/bin/bash
I=`dpkg -s chromium | grep "Status" `
if [ -n "$I" ]
then
   cp -r .sielsi/ $HOME
   cd $HOME/.sielsi/
   cp sielsi.desktop $HOME/Desktop
   echo "All is OK!"
else
   sudo apt install chromium
   cp -r .sielsi/ $HOME
   cd $HOME/.sielsi/
   cp sielsi.desktop $HOME/Desktop
   echo "All is OK!"
fi


